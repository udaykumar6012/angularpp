package com.jpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class VehicleDetails {
	@Id
	@GeneratedValue
private int id;
private String vehicleName;
@ManyToOne
private UserDetails user1;

public UserDetails getUser1() {
	return user1;
}
public void setUser1(UserDetails user1) {
	this.user1 = user1;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getVehicleName() {
	return vehicleName;
}
public void setVehicleName(String vehicleName) {
	this.vehicleName = vehicleName;
}
@Override
public String toString() {
	return "VehicleDetails [id=" + id + ", vehicleName=" + vehicleName + "]";
}


}
