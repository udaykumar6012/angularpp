package com.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity

public class UserDetails {
	@Id
	
	@GeneratedValue
private int id;
private String name;
@OneToMany(cascade=CascadeType.ALL)
private List<VehicleDetails>vehicle= new ArrayList<>();


public List<VehicleDetails> getVehicle() {
	return vehicle;
}
public void setVehicle(List<VehicleDetails> vehicle) {
	this.vehicle = vehicle;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Override
public String toString() {
	return "UserDetails [id=" + id + ", name=" + name + "]";
}

}
