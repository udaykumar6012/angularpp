package com.book1;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class Author {
@Id
@GeneratedValue
private int ID;
private String name;
@OneToMany(cascade=CascadeType.ALL)
@JoinTable(joinColumns=@JoinColumn(name="authorId"),
inverseJoinColumns=@JoinColumn(name="isbn"),
name="bookAuthor")
private List<Book> book=new ArrayList<>();


@Override
public String toString() {
	return "Author [ID=" + ID + ", name=" + name + ", book=" + book + "]";
}
public List<Book> getBook() {
	return book;
}
public void setBook(List<Book> book) {
	this.book = book;
}
public int getID() {
	return ID;
}
public void setID(int iD) {
	ID = iD;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}


}
