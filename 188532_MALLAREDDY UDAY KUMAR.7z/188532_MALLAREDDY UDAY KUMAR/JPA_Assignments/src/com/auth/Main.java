package com.auth;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
	public static void main(String args[]) {
		AuthorDetails adobj=new AuthorDetails();
		adobj.setAuthorId(123);
		adobj.setFirstName("joanne");
		adobj.setLastName("k");
		adobj.setMiddleName("Rowling");
		adobj.setPhno("987654321");
		adobj.setAuthorId(124);
		adobj.setFirstName("j");
		adobj.setLastName("chetan");
		adobj.setMiddleName("bhagat");
		adobj.setPhno("987654345");
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		AuthorDetails u=em.find(AuthorDetails.class,125);
		em.getTransaction().begin();
		/*u.setFirstName("john");
		em.remove(u);*/
		System.out.println(u);
		em.getTransaction().commit();
		System.out.println("Data Saved");
	
	}
}
