package com.cg.customerapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.customerapp.bean.Customer;
import com.cg.customerapp.exception.CustomerException;
import com.cg.customerapp.service.CustomerService;


@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	@RequestMapping("/customer")
	public  List<Customer> getCustomers() throws CustomerException {
		return customerService.getAllCustomers();
	}
	
	
	  @RequestMapping(value="/customer/add",method=RequestMethod.POST) 
	  public List<Customer> addCustomer(@RequestBody Customer cust) throws CustomerException{ 
		  return customerService.addCustomer(cust); 
    }
	 

	
	/*
	 * @RequestMapping(value="/customer/add", method=RequestMethod.POST) public
	 * ResponseEntity<String> addCustomer(@RequestBody Customer customer) throws
	 * CustomerException { customerService.addCustomer(customer); return new
	 * ResponseEntity<String>("Customer Added Successfully",HttpStatus.CREATED); }
	 */
	 
	@RequestMapping("/customer/{id}")
    public Customer getCustomerById(@PathVariable("id") int id) throws CustomerException {
        return customerService.getCustomerById(id);
        
    }
	
	@RequestMapping(value="/customer/{id}", method=RequestMethod.DELETE)
    public ResponseEntity<String> deleteCustomer(@PathVariable("id") int id) throws CustomerException {
        customerService.deleteCustomer(id);
        return new ResponseEntity<String>("Customer Deleted Successfully",HttpStatus.OK);
    }
	
	
	/*
	 * @RequestMapping(value="/customer/{id}",method=RequestMethod.PUT)
	 * 
	 * public List<Customer> updateProduct(@RequestBody Customer cust,@PathVariable
	 * int id) throws CustomerException {
	 * 
	 * return customerService.updateCustomer(id, cust);
	 * 
	 * }
	 */	
	
	  @RequestMapping(value="/customer/{id}", method=RequestMethod.PUT) 
	  public ResponseEntity<String> updateCustomer(@PathVariable("id") int id, @RequestBody Customer customer) throws CustomerException {
	  customerService.updateCustomer(id,customer); return new
	  ResponseEntity<String>("Customer Updated Successfully",HttpStatus.OK); 
	  }
	 
	@RequestMapping(value="/customer/{id}/{city}/{type}", method=RequestMethod.PUT)
    public ResponseEntity<String> updateCustomer(@PathVariable("id") int id, @PathVariable("city") String city,@PathVariable("type") String type) throws CustomerException {
        customerService.updateCustomer(id,city,type);
        return new ResponseEntity<String>("Customer Updated Successfully",HttpStatus.OK);
    }
	
	@RequestMapping("/getCustomerByCity/city")
	public List<Customer> findCustomerByCity(@RequestParam("city")String city) throws CustomerException{
		return customerService.getCustomerByCity(city);
	}
	
	/*
	 * @ExceptionHandler({CustomerException.class}) public ResponseEntity<String>
	 * handleErrors(Exception e){ return new
	 * ResponseEntity<String>("An Error occured "+e.getMessage(),HttpStatus.CONFLICT
	 * ); }
	 */
}
