
    
package com.cg.emp.bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;


@Entity

public class Employee {
    
    @Id
    private int id;
    @Pattern(regexp="[A-Z][A-Za-z\\s]{2,}",message="Name should start with a Capital letter")
    private String name;
    private String gender;
    @Min(18)
    @Max(60)
    private int age;
    @Column(name="mobilenumber")
    @Pattern(regexp="\\d{10}",message="Mobile Number should be 10 digits")
    private String mobile;
    private double salary;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
    @Override
    public String toString() {
        return "Employee [id=" + id + ", name=" + name + ", gender=" + gender + ", age=" + age + ", mobile=" + mobile
                + ", salary=" + salary + "]";
    }
}






