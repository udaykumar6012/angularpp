package com.cg.parallel.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cg.parallel.bean.BankAccount;

@Repository
public interface BankDao extends JpaRepository<BankAccount,Integer>{
	
	@Query("from BankAccount where userName=:userName")
	BankAccount getCustomerDetails(@Param("userName") String userName);
	
	@Query("from BankAccount where userName=:userName and password=:password")
	BankAccount loginByUser(@Param("userName")String email,@Param("password") String password);
	
	@Query("from BankAccount where accountId=:accno")
    BankAccount getCustomerById(@Param("accno") int accountNo);

}
