package com.cg.parallel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.parallel.bean.BankAccount;
import com.cg.parallel.exception.BankException;
import com.cg.parallel.service.BankService;
 
@RestController
public class BankController 
{
    @Autowired
    BankService bankService;
    
    @RequestMapping("/customer/getcustomerDetails/{userName}")
    public BankAccount  getCustomers(@PathVariable String userName) throws BankException
    {
        return bankService.getCustomerDetails(userName);
    }
    
    @RequestMapping(value="/customer", method = RequestMethod.POST)
    public boolean addCustomers(@RequestBody BankAccount bank) throws BankException
    {
        return bankService.addCustomer(bank);
    }
    
    @RequestMapping("/customer/showbalance/{accountId}")
    public long showBalance(@PathVariable int accountId) throws BankException
    {
        return bankService.showBalance(accountId);
    }
    
    @RequestMapping(value = "/customer/deposit/{accountId}/{amount}",method=RequestMethod.PUT)
    public long depositMoney(@PathVariable int accountId,@PathVariable long amount) throws BankException
    {
        return bankService.depositMoney(accountId, amount);
    }
    
    @RequestMapping(value = "/customer/withdraw/{accountId}/{amount}",method=RequestMethod.PUT)
    public long withdrawMoney(@PathVariable int accountId,@PathVariable long amount) throws BankException
    {
        return bankService.withdrawMoney(accountId, amount);
    }
    
    @RequestMapping(value = "/customer/fundtransfer/{accountId1}/{accountId2}/{amount}",method=RequestMethod.PUT)
    public boolean fundTransfer(@PathVariable int accountId1,@PathVariable int accountId2,@PathVariable long amount) throws BankException
    {
        return bankService.fundTransfer(accountId1, accountId2, amount);
    }
    @RequestMapping(value = "/customer/{userName}/{password}")
    public BankAccount loginByUser(@PathVariable("userName")String userName,@PathVariable("password") String password) throws BankException
    {
        return bankService.loginByUser(userName, password);
    }
}