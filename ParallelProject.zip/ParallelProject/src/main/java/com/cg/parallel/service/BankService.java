package com.cg.parallel.service;

import com.cg.parallel.bean.BankAccount;
import com.cg.parallel.exception.BankException;

public interface BankService {
	
	public boolean addCustomer(BankAccount bankAccount) throws BankException;
	public BankAccount getCustomerDetails(String userName) throws BankException;
	public BankAccount loginByUser(String userName,String password) throws BankException; 
	public long depositMoney(int accountId,long amount) throws BankException;
	public long withdrawMoney(int accountId,long amount) throws BankException;
	public long showBalance(int accountId) throws BankException;
	public boolean fundTransfer(int accountId1,int accountId2, long amount) throws BankException;
	

}
