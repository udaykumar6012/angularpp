package com.cg.parallel.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.parallel.bean.BankAccount;
import com.cg.parallel.dao.BankDao;
import com.cg.parallel.exception.BankException;

@Service
public class BankServiceImpl implements BankService{

	@Autowired
	BankDao bankDao;

	@Override
	public boolean addCustomer(BankAccount bankAccount) throws BankException {
		try {
			bankDao.save(bankAccount);
			return true;
		}
		catch(Exception exception) {
			throw new BankException(exception.getMessage());
		}
	}


	@Override
	public BankAccount getCustomerDetails(String userName) throws BankException {
		try {
			return  bankDao.getCustomerDetails(userName);
		}catch (Exception exception) {
			throw new BankException(exception.getMessage());
		}

	}

	@Override
	public BankAccount loginByUser(String userName, String password) throws BankException {
		try {
			return bankDao.loginByUser(userName, password);
		}catch(Exception exception) {
			throw new BankException(exception.getMessage());
		}
	}

	@Override
	public long depositMoney(int accountId, long amount) throws BankException {
		try {
			BankAccount temp = bankDao.getCustomerById(accountId);
            long currentBalance = temp.getBalance();
            long updatedBalance = amount + currentBalance;
            temp.setBalance(updatedBalance);
            bankDao.save(temp);
            return updatedBalance;
		}
		catch(Exception exception) {
			throw new BankException(exception.getMessage());
		}


	}

	@Override
	public long withdrawMoney(int accountId, long amount) throws BankException {
		try {
			BankAccount temp = bankDao.getCustomerById(accountId);
            long currentBalance = temp.getBalance();
            long updatedBalance = currentBalance-amount;
            temp.setBalance(updatedBalance);
            bankDao.save(temp);
            return updatedBalance;
			}catch(Exception exception) {
			throw new BankException(exception.getMessage());
		}

	}

	@Override
	public long showBalance(int accountId) throws BankException {
		try {
			BankAccount temp = bankDao.getCustomerById(accountId);
			return temp.getBalance();
		}
		catch(Exception exception){
			throw new BankException(exception.getMessage());
		}

	}

	@Override
	public boolean fundTransfer(int accountId1, int accountId2, long amount) throws BankException {
		try {
			BankAccount temp1 = bankDao.getCustomerById(accountId1);
            long currentBalance1 = temp1.getBalance();
            long updatedBalance1 = amount + currentBalance1;
            temp1.setBalance(updatedBalance1);
            bankDao.save(temp1);

			

			BankAccount temp2 = bankDao.getCustomerById(accountId2);
            long currentBalance2 = temp2.getBalance();
            long updatedBalance2 = currentBalance2-amount;
            temp2.setBalance(updatedBalance2);
            bankDao.save(temp2);
         
			return true;

		}catch(Exception exception) {
			throw new BankException(exception.getMessage());
		}
	}


}
