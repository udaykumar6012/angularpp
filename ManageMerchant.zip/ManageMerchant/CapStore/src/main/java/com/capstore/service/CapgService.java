package com.capstore.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Optional;

import javax.xml.bind.DatatypeConverter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.bean.Credential;
import com.capstore.bean.Customer;
import com.capstore.bean.Merchant;
import com.capstore.bean.MyMail;
import com.capstore.bean.ThirdPartyMerchant;
import com.capstore.bean.WishItem;
import com.capstore.dao.CredentialsDao;
import com.capstore.dao.CustomerDao;
import com.capstore.dao.MerchantDao;
import com.capstore.dao.MyMailDao;
import com.capstore.dao.ThirdPartyDao;
import com.capstore.dao.WishItemDao;

@Service
public class CapgService implements CapgServiceInterface {

	@Autowired MerchantDao merchantRepo;
	@Autowired ThirdPartyDao thirdPartyRepo;
	@Autowired CredentialsDao credentialDao;
	@Autowired MyMailDao mailDao;
	@Override
	public List<Merchant> addMerchant(Merchant merchant, String password)throws NoSuchAlgorithmException  {
		merchant.setIsValid("ACCEPTED");
		
		merchantRepo.save(merchant);
		Credential cred = new Credential();
		cred.setId(merchant.getMerId());
        cred.setPassword(password);
        credentialDao.save(cred);
		return merchantRepo.findAll();
	}

	@Override
	public List<Merchant> deleteMerchant(String merId) {
		Merchant deleteProduct=merchantRepo.findById(merId).get();
		merchantRepo.delete(deleteProduct);
		return merchantRepo.findAll();
	}

	@Override
	public List<ThirdPartyMerchant> inviteThirdParty(ThirdPartyMerchant thirdParty) {
		thirdPartyRepo.save(thirdParty);
		return thirdPartyRepo.findAll();
	}

	@Override
	public List<Merchant> getAllMerchants() {
		// TODO Auto-generated method stub
		return merchantRepo.findAll();
	}

	@Override
	public List<ThirdPartyMerchant> getAllInvities() {
		// TODO Auto-generated method stub
		return thirdPartyRepo.findAll();
	}
	@Override
	public String encryptPassword(String password)  throws NoSuchAlgorithmException {
		       
	        Credential cred = new Credential();
	       MessageDigest md = MessageDigest.getInstance("MD5");
	       md.update(password.getBytes());
	        byte[] digest = md.digest();
	        String myHash = DatatypeConverter.printHexBinary(digest).toUpperCase();
	     //   cred.setPassword(myHash);
	        return myHash;
	    }
	@Override
	public void sendMail(MyMail maildata) {
		
		mailDao.save(maildata);
	}

	@Override
	public List<MyMail> getMyMails() {
		// TODO Auto-generated method stub
		
		return mailDao.getMailsBydata();
	}
	@Override
	public List<MyMail> getInbox() {
		// TODO Auto-generated method stub
		
		return mailDao.getInboxBydata();
	}
	}

