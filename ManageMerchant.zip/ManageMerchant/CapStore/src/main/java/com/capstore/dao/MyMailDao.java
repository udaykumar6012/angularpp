package com.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capstore.bean.MyMail;

@Repository
public interface MyMailDao extends JpaRepository<MyMail, Integer>{
	@Query("from MyMail where fromm='durgareddy1997@gmail.com'")
    List<MyMail> getMailsBydata();

	@Query("from MyMail where too='durgareddy1997@gmail.com'")
    List<MyMail> getInboxBydata();


}