package com.capstore.bean;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MYMAIL")
public class MyMail {

	@Id
	@GeneratedValue
	private int id;
	private String fromm;
	private String too;
	private String maildata;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFromm() {
		return fromm;
	}
	public void setFromm(String fromm) {
		this.fromm = fromm;
	}
	public String getToo() {
		return too;
	}
	public void setToo(String too) {
		this.too = too;
	}
	public String getMaildata() {
		return maildata;
	}
	public void setMaildata(String maildata) {
		this.maildata = maildata;
	}
	@Override
	public String toString() {
		return "MyMail [id=" + id + ", from=" + fromm + ", to=" + too + ", maildata=" + maildata + "]";
	}
	
}

