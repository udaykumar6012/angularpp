package com.capstore.controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.Merchant;
import com.capstore.bean.MyMail;
import com.capstore.bean.ThirdPartyMerchant;
import com.capstore.service.CapgService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class CapgController {

	@Autowired CapgService capgService;
	
	@RequestMapping("ecommerce/185697/showmerchants") 
	public List<Merchant> getAllMerchants() {
		return capgService.getAllMerchants();
	}
	@RequestMapping(value="ecommerce/185697/addDedicatedMerchant/{password}",method=RequestMethod.POST) 
	  public List<Merchant> addMerchant(@RequestBody Merchant merchant,@PathVariable String password) throws NoSuchAlgorithmException {
		String password1=capgService.encryptPassword(password);
		 return capgService.addMerchant(merchant,password1);
	}
	@RequestMapping(value="ecommerce/185697/deletemerchant/{merId}",method=RequestMethod.DELETE) 
	  public List<Merchant> deleteMerchant(@PathVariable("merId") String merId) { 
		  return capgService.deleteMerchant(merId); 
	}
	@RequestMapping(value="ecommerce/185697/invitemerchant",method=RequestMethod.POST) 
	  public List<ThirdPartyMerchant> inviteMerchant(@RequestBody ThirdPartyMerchant inviteThirdParty) { 
		 return capgService.inviteThirdParty(inviteThirdParty);
	}
	@RequestMapping("ecommerce/185697/invities") 
	public List<ThirdPartyMerchant> getAllInvities() {
		return capgService.getAllInvities();
	}
	
	
	@PostMapping("ecommerce/185697/send")
	public void sendMail(@RequestBody MyMail maildata){
		capgService.sendMail(maildata);
	}
	
	@GetMapping("ecommerce/185697/getmymail")
	public List<MyMail> getMyMails() {
		return capgService.getMyMails();
	}
	@GetMapping("ecommerce/185697/getInbox")
	public List<MyMail> getInbox() {
		return capgService.getInbox();
	}
	@PostMapping("/ecommerce/186138/addThirdParty/{password}")
    public void registerMerchant(@RequestBody Merchant merchant,@PathVariable("password") String pass) throws NoSuchAlgorithmException {
        String password1=capgService.encryptPassword(pass);
         capgService.addMerchant(merchant,password1);
    }
}
