package com.capstore.service;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import com.capstore.bean.Merchant;
import com.capstore.bean.MyMail;
import com.capstore.bean.ThirdPartyMerchant;


public interface CapgServiceInterface {
	
	public List<Merchant> addMerchant(Merchant merchant,String password) throws NoSuchAlgorithmException;
	public List<Merchant> deleteMerchant(String merId);
	public List<ThirdPartyMerchant> inviteThirdParty(ThirdPartyMerchant thirdParty);
	public List<Merchant> getAllMerchants();
	public List<ThirdPartyMerchant> getAllInvities();
	void sendMail(MyMail maildata);
	String encryptPassword(String password) throws NoSuchAlgorithmException;

	List<MyMail> getMyMails();
	List<MyMail> getInbox();

}
