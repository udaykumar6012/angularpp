export class Merchant {
    firstName: string;
    lastName: string;
    emailId: string;
    panCard: string;
    phoneNo: string;
    address: string;
    isValid: string;
    merType: string;
    
    
   }
