import { Component, OnInit } from '@angular/core';
import { MailM } from '../mail-m';
import { MerchantService } from '../merchant.service';

@Component({
  selector: 'app-sentbox',
  templateUrl: './sentbox.component.html',
  styleUrls: ['./sentbox.component.css']
})
export class SentboxComponent implements OnInit {
  message:string="haii";
  array: MailM[];
  constructor(private mail:MerchantService) { }

  ngOnInit() {
    this.mail.getMail().subscribe(data=>this.responseData(data));
  }

  responseData(data){
    this.array=data;
  }
}
