import { MailM } from './mail-m';

describe('MailM', () => {
  it('should create an instance', () => {
    expect(new MailM()).toBeTruthy();
  });
});
