import { Component, OnInit } from '@angular/core';
import { Merchant } from '../merchant';
import { MerchantService } from '../merchant.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-merchant',
  templateUrl: './add-merchant.component.html',
  styleUrls: ['./add-merchant.component.css']
})
export class AddMerchantComponent implements OnInit {

  
  constructor(private merchantService: MerchantService, private routes: Router) { }

  ngOnInit() {
    this.merchantService.setFromAdminDD(true);
    this.routes.navigateByUrl("/register");
  }
  }
