import { Component, OnInit } from '@angular/core';
import { MailM } from '../mail-m';
import { MerchantService } from '../merchant.service';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.css']
})
export class InboxComponent implements OnInit {

  array: MailM[];
  constructor(private mail:MerchantService) { }

  ngOnInit() {
    this.mail.getInbox().subscribe(data=>this.responseData(data));
  }

  responseData(data){
    this.array=data;
  }


}
