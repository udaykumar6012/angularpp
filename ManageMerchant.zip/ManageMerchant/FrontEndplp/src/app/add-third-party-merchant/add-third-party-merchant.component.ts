import { Component, OnInit } from '@angular/core';
import { MerchantService } from '../merchant.service';
import { Merchant } from '../merchant';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-third-party-merchant',
  templateUrl: './add-third-party-merchant.component.html',
  styleUrls: ['./add-third-party-merchant.component.css']
})
export class AddThirdPartyMerchantComponent implements OnInit {
  constructor(private merchantService: MerchantService, private routes: Router) { }

  ngOnInit() {
    this.merchantService.setFromAdminTP(true);
    this.routes.navigateByUrl("/register");
  }
  
  }

