import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RemoveMerchantComponent } from './remove-merchant/remove-merchant.component';
import { AddMerchantComponent } from './add-merchant/add-merchant.component';
import { ManageMerchantComponent } from './manage-merchant/manage-merchant.component';
import { InviteMerchantComponent } from './invite-merchant/invite-merchant.component';
import { InboxComponent } from './inbox/inbox.component';
import { SentboxComponent } from './sentbox/sentbox.component';
import { AddThirdPartyMerchantComponent } from './add-third-party-merchant/add-third-party-merchant.component';
import { SignUpMerchantComponent } from './sign-up-merchant/sign-up-merchant.component';



const routes: Routes = [
  {
    path: 'firstParty',
    component: AddMerchantComponent
  },
  {
    path: 'register',
    component: SignUpMerchantComponent
  },
  {
    path: 'thirdParty',
    component: AddThirdPartyMerchantComponent
  },
  {
    path: 'delete',
    component: RemoveMerchantComponent
  },
  {
    path:'',
    component:ManageMerchantComponent
  },
  {
    path:'inviteThirdParty',
    component:InviteMerchantComponent
  },
  {
    path:'inbox',
    component:InboxComponent
  },
  {
    path:'sentbox',
    component:SentboxComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
