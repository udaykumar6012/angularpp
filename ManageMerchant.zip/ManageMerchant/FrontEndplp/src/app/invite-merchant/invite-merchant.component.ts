import { Component, OnInit } from '@angular/core';
import { ThirdParty } from '../third-party';
import { MerchantService } from '../merchant.service';
import { MailM } from '../mail-m';

@Component({
  selector: 'app-invite-merchant',
  templateUrl: './invite-merchant.component.html',
  styleUrls: ['./invite-merchant.component.css']
})
export class InviteMerchantComponent implements OnInit {
  thirdParty:ThirdParty;
  constructor(private merchantService: MerchantService) { }


  maill: MailM;

  
  sendMail(fromm:string,too:string,maildata:string,name:string){
    this.maill=new MailM(fromm,too,maildata);
    this.merchantService.sendMail(this.maill).subscribe();
    this.thirdParty = new ThirdParty(name,too);
    console.log(this.thirdParty);
      this.merchantService.inviteMerchant(this.thirdParty)
        .subscribe();
      
  }


  ngOnInit() {
  }


  
}
