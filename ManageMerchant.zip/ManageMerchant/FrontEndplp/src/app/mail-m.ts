export class MailM{
    fromm:string;
    too:string;
    maildata:string;
   constructor(fromm:string, too:string,maildata:string){
       this.fromm=fromm;
       this.too=too;
       this.maildata=maildata;
 
   }
   
     } 