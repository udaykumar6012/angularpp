import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddMerchantComponent } from './add-merchant/add-merchant.component';
import { RemoveMerchantComponent } from './remove-merchant/remove-merchant.component';
import { InviteMerchantComponent } from './invite-merchant/invite-merchant.component';
import { ManageMerchantComponent } from './manage-merchant/manage-merchant.component';
import { HttpClientModule } from '@angular/common/http';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { InboxComponent } from './inbox/inbox.component';
import { SentboxComponent } from './sentbox/sentbox.component';
import { AddThirdPartyMerchantComponent } from './add-third-party-merchant/add-third-party-merchant.component';
import { SignUpMerchantComponent } from './sign-up-merchant/sign-up-merchant.component';


@NgModule({
  declarations: [
    AppComponent,
    AddMerchantComponent,
    RemoveMerchantComponent,
    InviteMerchantComponent,
    ManageMerchantComponent,
    InboxComponent,
    SentboxComponent,
    AddThirdPartyMerchantComponent,
    SignUpMerchantComponent,
   
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatDialogModule,
    BrowserAnimationsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
