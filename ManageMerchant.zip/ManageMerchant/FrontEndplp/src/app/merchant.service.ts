import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Merchant } from './merchant';
import { ThirdParty } from './third-party';
import { MailM } from './mail-m';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MerchantService {
  private fromAdminDD=false;
  private fromAdminTP=false;
 private baseUrl='http://localhost:9097/ecommerce/';
 
  constructor(private httpClient:HttpClient) { }
  public setFromAdminDD(fromAdminDD: boolean) {
    this.fromAdminDD = fromAdminDD;
    }
    
    public getFromAdminDD() {
    return this.fromAdminDD;
    }
  public  setFromAdminTP(fromAdminTP: boolean) {
    this.fromAdminTP = fromAdminTP;
    }
    
   public getFromAdminTP() {
    return this.fromAdminTP;
    }
   



  public addMerchant(merchant:Merchant,password:string) {
    return this.httpClient.post<Merchant>(this.baseUrl+'/185697/addDedicatedMerchant/'+password,merchant);

  };
  public deleteMerchant(merId:string) {
    return this.httpClient.delete<Merchant>(this.baseUrl+'185697/deletemerchant/'+ merId);

  };
  public inviteMerchant(thirdParty:ThirdParty){
    return this.httpClient.post<ThirdParty>(this.baseUrl+ '185697/invitemerchant',thirdParty);
  };
  public sendMail(mail:MailM){
    return this.httpClient.post<MailM>(this.baseUrl+"185697/send",mail);
  };
  public getMail(){
    return this.httpClient.get<MailM>(this.baseUrl+"185697/getmymail");
  }
  public getInbox(){
    return this.httpClient.get<MailM>(this.baseUrl+"185697/getInbox");
  }
  public AddThirdParty(thirdParty: Merchant, password: string): Observable<Merchant> {
    return this.httpClient.post<Merchant>(this.baseUrl+'186138/addThirdParty/' + password, thirdParty);
    }

}
