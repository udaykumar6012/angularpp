import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-transactions',
  templateUrl: './show-transactions.component.html',
  styleUrls: ['./show-transactions.component.css']
})
export class ShowTransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
