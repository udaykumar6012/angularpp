import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfer-amount',
  templateUrl: './transfer-amount.component.html',
  styleUrls: ['./transfer-amount.component.css']
})
export class TransferAmountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
