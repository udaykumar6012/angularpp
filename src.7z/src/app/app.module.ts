import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositAmountComponent } from './deposit-amount/deposit-amount.component';
import { WithdrawAmountComponent } from './withdraw-amount/withdraw-amount.component';
import { TransferAmountComponent } from './transfer-amount/transfer-amount.component';
import { ShowTransactionsComponent } from './show-transactions/show-transactions.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateAccountComponent,
    ShowBalanceComponent,
    DepositAmountComponent,
    WithdrawAmountComponent,
    TransferAmountComponent,
    ShowTransactionsComponent,
    SignupComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
