package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capg.bean.Customer;

public interface CustomerSearchDao extends JpaRepository<Customer, String> {

	@Query("from Customer where UPPER(firstName)=:customerName or UPPER(lastName)=:customerName")
	public List<Customer> getCustomerDetailsByName(@Param("customerName") String customerName);
}
