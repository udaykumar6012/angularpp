package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.bean.Product;

@Repository
public interface ProductSearchDao extends JpaRepository<Product,String>{
	@Query("from Product where UPPER(prodCategory)=:prodCategory")
	List<Product> getProductDetailsbyCategory(@Param("prodCategory") String prodCategory);
	
	@Query("from Product where UPPER(prodName)=:prodName")
	List<Product> getProductDetailsbyName(@Param("prodName") String prodName);
	
	@Query("from Product where UPPER(prodCategory)=:prodCategory and merchant_merId=:merchantId")
	List<Product> getMerchantProductDetailsbyCategory(@Param("prodCategory") String prodCategory,@Param("merchantId") String merchantId);
	
	@Query("from Product where UPPER(prodName)=:prodName and merchant_merId=:merchantId")
	List<Product> getMerchantProductDetailsbyName(@Param("prodName") String prodName,@Param("merchantId") String merchantId);
	
}
