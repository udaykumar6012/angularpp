package com.capg.service;
import java.util.List;

import com.capg.bean.Customer;
import com.capg.bean.Merchant;
import com.capg.bean.Product;

public interface SearchService {

	
	List<Product> getProductDetailsbyCategory(String prodCategory);
	List<Product> getProductDetailsbyName(String prodName);
	List<Product> getMerchantProductsByCategory(String merchantId, String prodCategory);
	
	List<Product> getMerchantProductsByName(String merchantId, String prodName);
	
	List<Customer> getCustomerDetailsByName(String customerName);
	
	List<Merchant> getMerchantDetailsByName(String merchantName);
	
}
