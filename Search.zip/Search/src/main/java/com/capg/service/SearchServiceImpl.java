package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Customer;
import com.capg.bean.Merchant;
import com.capg.bean.Product;
import com.capg.dao.CustomerSearchDao;
import com.capg.dao.MerchantSearchDao;
import com.capg.dao.ProductSearchDao;
@Service
public class SearchServiceImpl implements SearchService {
	@Autowired ProductSearchDao productSearchDao;
	@Autowired MerchantSearchDao merchantSearchDao;
	@Autowired CustomerSearchDao customerSearchDao;
	@Override
	public List<Product> getProductDetailsbyCategory(String prodCategory) {
		String upperCasedCategory=prodCategory.toUpperCase();

		return productSearchDao.getProductDetailsbyCategory(upperCasedCategory);
	}

	@Override
	public List<Product> getProductDetailsbyName(String prodName) {

		String upperCasedName = prodName.toUpperCase();
		return productSearchDao.getProductDetailsbyName(upperCasedName);
	}
	
	@Override
	public List<Product> getMerchantProductsByCategory(String merchantId, String prodCategory) {
		List<Product> products  = productSearchDao.getMerchantProductDetailsbyCategory(prodCategory, merchantId);
		return products;
	}
	
	@Override
	public List<Product> getMerchantProductsByName(String merchantId, String prodName) {
		List<Product> products = productSearchDao.getMerchantProductDetailsbyName(prodName, merchantId);
		return products;
	}
	
	@Override
	public List<Customer> getCustomerDetailsByName(String customerName) {
		List<Customer> customers = customerSearchDao.getCustomerDetailsByName(customerName);
		return customers;
	}
	
	@Override
	public List<Merchant> getMerchantDetailsByName(String merchantName) {
		List<Merchant> merchants = merchantSearchDao.getMerchantDetailsByName(merchantName);
		return merchants;
	}
	
	
}
