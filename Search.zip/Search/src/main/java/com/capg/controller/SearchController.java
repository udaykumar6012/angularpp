package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Customer;
import com.capg.bean.Merchant;
import com.capg.bean.Product;
import com.capg.service.SearchService;

@RestController
public class SearchController {
	@Autowired
	SearchService searchService;
	
	
	@RequestMapping("ecommerce/185532/searchProdByCategory/{prodCategory}")
	public List<Product> getProductDetailsbyCategory(@PathVariable String prodCategory){
		return searchService.getProductDetailsbyCategory(prodCategory);

	}

	@RequestMapping("ecommerce/185532/searchProdByName/{prodName}")
	public List<Product> getProductDetailsbyName(@PathVariable String prodName){
		return searchService.getProductDetailsbyName(prodName);
	}
	
	@RequestMapping("ecommerce/185532/searchCustomerByName/{custName}")
	public List<Customer> getCustomerDetailsByName(@PathVariable String custName) {
		return searchService.getCustomerDetailsByName(custName);
	}
	
	@RequestMapping("ecommerce/185532/searchMerchantByName/{merchName}")
	public List<Merchant> getMerchantDetailsByName(@PathVariable String merchName) {
		return searchService.getMerchantDetailsByName(merchName);
	}
	
	@RequestMapping("ecommerce/185532/getMerchantProductsByCategory/{merchId}/{prodCategory}")
	public List<Product> getMerchantProductsByCategory(@PathVariable String merchId,@PathVariable String prodCategory) {
		return searchService.getMerchantProductsByCategory(merchId, prodCategory);
	}
	
	
}
